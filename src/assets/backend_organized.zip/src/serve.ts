// serve.ts - inicialização do servidor
