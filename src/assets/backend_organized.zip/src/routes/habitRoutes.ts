// habitRoutes.ts - código conforme organização sugerida
