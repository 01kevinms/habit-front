// authRoutes.ts - código conforme organização sugerida
