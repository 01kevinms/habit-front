// habitService.ts - código conforme organização sugerida
