// statsService.ts - código conforme organização sugerida
