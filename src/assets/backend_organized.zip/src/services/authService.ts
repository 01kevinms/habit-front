// authService.ts - código conforme organização sugerida
