// jwt.ts - código conforme organização sugerida
