// authController.ts - código conforme organização sugerida
