// habitController.ts - código conforme organização sugerida
