// statsController.ts - código conforme organização sugerida
