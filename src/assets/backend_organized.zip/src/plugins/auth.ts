// auth.ts - código conforme organização sugerida
