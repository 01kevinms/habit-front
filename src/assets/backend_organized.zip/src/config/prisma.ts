// prisma.ts - código conforme organização sugerida
