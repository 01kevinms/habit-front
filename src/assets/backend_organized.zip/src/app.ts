// app.ts - configuração principal do Fastify
